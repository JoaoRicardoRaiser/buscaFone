const Model = async (url, method, params) => {
  "use strict"; // Start of use strict

  const headers = new Headers();
  headers.append('Content-Type', 'application/json;charset=UTF-8');

  const response = await fetch(
    `${url}`,
    {
      method: `${method}`,
      body: params,
      headers,
    },
  );

  if (!response.ok) {
    throw new Error(
      'Não foi possivel buscar os dados!',
    );
  }

  const payload = await response.json();
  return payload;
}; // End of use strict