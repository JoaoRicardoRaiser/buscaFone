
const Respostas = (($) => {
  const controlStorage = (q, r) => {
    let resp = localStorage.getItem('respostas');
    resp = JSON.parse(resp)
    if (resp) {

      if (resp[q]) {
        resp[q] = r;
        localStorage.setItem('respostas', JSON.stringify(resp))
      } else {
        let obj = {};
        obj[q] = r;
        resp = Object.assign(resp, obj)
        localStorage.setItem('respostas', JSON.stringify(resp))
      }

    } else {
      let obj = {};
      obj[q] = r;
      localStorage.setItem('respostas', JSON.stringify(obj))
    }
  };

  // MUDAR CHAMADA PARA O BACKEND
  const getRes = () => {
    let respostas = localStorage.getItem('respostas');
    respostas = JSON.parse(respostas); // {processador: 8, q2: 'r3', q3: 'r1'}

    if (!respostas) {
      alert('Você precisa responder as questões!')
      return
    }

    Model('https://jsonplaceholder.typicode.com/todos/1', 'GET', respostas).then((res) => {
      // sucesso
      localStorage.clear('respostas');
      $(`<p>${res.title}</p>`).appendTo('.resultado')
      $(`<p>${res.title}</p>`).appendTo('.intro-lead-in')
      $(`<p>${res.title}</p>`).appendTo('.intro-heading')

    }).catch((e) => {
      const error = e.message
      alert(error);
    });    
  }


  $('.q1r1').click(() => {
    Respostas.ctrlStorage('processador', 8)
  })
  $('.q1r2').click(() => {
    Respostas.ctrlStorage('processador', 2)
  })
  $('.q1r3').click(() => {
    Respostas.ctrlStorage('processador', 4)
  })


  $('.q2r1').click(() => {
    Respostas.ctrlStorage('q2', 'r1')
  })
  $('.q2r2').click(() => {
    Respostas.ctrlStorage('q2', 'r2')
  })
  $('.q2r3').click(() => {
    Respostas.ctrlStorage('q2', 'r3')
  })


  $('.q3r1').click(() => {
    Respostas.ctrlStorage('q3', 'r1')
  })
  $('.q3r2').click(() => {
    Respostas.ctrlStorage('q3', 'r2')
  })
  $('.q3r3').click(() => {
    Respostas.ctrlStorage('q3', 'r3')
  })


  $('.q4r1').click(() => {
    Respostas.ctrlStorage('q4', 'r1')
  })
  $('.q4r2').click(() => {
    Respostas.ctrlStorage('q4', 'r2')
  })
  $('.q4r3').click(() => {
    Respostas.ctrlStorage('q4', 'r3')
  })


  $('.q5r1').click(() => {
    Respostas.ctrlStorage('q5', 'r1')
  })
  $('.q5r2').click(() => {
    Respostas.ctrlStorage('q5', 'r2')
  })
  $('.q5r3').click(() => {
    Respostas.ctrlStorage('q5', 'r3')
  })


  $('.q6r1').click(() => {
    Respostas.ctrlStorage('q6', 'r1')
  })
  $('.q6r2').click(() => {
    Respostas.ctrlStorage('q6', 'r2')
  })
  $('.q6r3').click(() => {
    Respostas.ctrlStorage('q6', 'r3')
  })


  $('.q7').click(() => {
    const value = $('.input-q7')[0].value;
    if (value) {
      Respostas.ctrlStorage('q7', value);
    } else {
      alert('Adicione um Valor');
    }
  })

  return {
    ctrlStorage: controlStorage,
    getResultados: getRes
  }
  
})(jQuery);